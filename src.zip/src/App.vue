<template>
    <div>
        <iv-visualisation :title="projectName">
            <template #hotspots>
                <iv-pane position="left">
                    <iv-sidebar-content :showPagination="false">
                        <iv-sidebar-section :title="projectName">
                            Next all we have to do is incorporate Snell's Law of refraction. This law states that: <br>
                            <iv-equation-box equation="\frac{sin(\theta_{i})}{sin(\theta_{t})} = \frac{n_{t}}{n_{i}}"></iv-equation-box>
                            <br>
                            From this we can see that given a certain refractive index ratio, the outgoing direction of a wave can be determined if the incoming direction is known.
                            So Snell's law combined with boundary conditions allows us to calculate reflected and refractive waves given the incident.

                        </iv-sidebar-section>
                    </iv-sidebar-content>
                </iv-pane>

                <iv-toggle-hotspot position="bottom" title="Sliders">
                     <div id="angle-slider">
                        <label for="angle" class="sliderTitle">Angle of incidence:
                            <span id="angle-display"></span>
                        </label><span class="sliderMin">0&deg;</span>
                        <input type="range" id="angle" name="angle" min="0" max="85" value="45" @change='angleUpdate'>
                        <span class="sliderMax">85&deg;</span>
                    </div>
                    <div id="refractive-index-slider">
                        <label for="refractive-index" class="sliderTitle">Refractive Index Ratio (n1/n2):
                            <span id="refractive-index-display"></span>
                        </label><span class="sliderMin">0.5</span>
                        <input type="range" id="refractive-index" name="refractive-index" min="0.5" max="2" step="0.02" value="1.5" @change='indexUpdate'>
                        <span class="sliderMax">2</span>
                    </div>
                </iv-toggle-hotspot>

            </template>

            <div id="graph" style="margin: 5vw; width: 70%"></div>

        </iv-visualisation>
    </div>
</template>
<script>
// import {name} from '../package.json';
import Plotly from 'plotly.js';
import $ from 'jquery';

export default {
    name:"App",
    data(){
        return {
            projectName: `Snell's Law`,
            refractiveIndexInput: this.init_index,
            angleInput: this.init_angle,
            redrawPlot: false,
        }
    },
    props: {
        init_index: {
            default: 1.5,
        },
        init_angle: {
            default: 45,
        }

    },
    methods:{
        angleUpdate(e){
            this.angleInput = e.target.value;
            this.redrawPlot = true;
        },
        indexUpdate(e){
            this.refractiveIndexInput = e.target.value;
            this.redrawPlot = true;
        }
    },
    mounted(){
            let v = this;

            let angleInput = v.angleInput;
            let refractiveIndexInput = v.refractiveIndexInput;

            var dom = {
                    //defining shorthands for our html elements
                    refractiveIndexInput: v.refractiveIndexInput,
                    refractiveIndexDisplay: $("#refractive-index-display"),
                    angleInput: v.angleInput,
                    angleDisplay: $("#angle-display")
                },
            // define initial layout for the plot
                plt = {
                    MaxTraceNo: 3,
                    layout: {
                        autosize: true, //make the plot the size of the div
                        xaxis: {
                            range: [-1, 1],
                            autorange: false,
                        },

                        yaxis: {
                            range: [-1, 1],
                            autorange: false,
                        },
                        margin: {
                        l: 40, r: 10, b: 60, t: 1, pad: 5
                    },
                    legend: {
                        x: 0, y: 10,
                        orientation: "h"
                    },
                    font: {
                        family: "Fira Sans",
                        size: 16
                    }
                    }
                },

                phys = {
                    polarisation: "s",
                    refractiveIndexIndex: 6,
                    angleIndex: 10,
                    data: [],
                    setPolarisation: function(polarisation) {
                        this.polarisation = polarisation;
                    },
                    setRefractiveIndexIndex: function(index) {
                        this.refractiveIndexIndex = index;
                    },
                    setAngleIndex: function(index) {
                        this.angleIndex = index;
                    },
                    getPlotData: function() {
                        return this.data[this.polarisation][this.refractiveIndexIndex][this.angleIndex];
                    },
                };

            //import JSON data from online
            $.when(
                $.getJSON("https://rawgit.com/binaryfunt/Imperial-Visualizations/master/dielectric_boundary_data3.JSON"),
                $.getJSON("https://rawgit.com/EdKeys/Imperial-Visualizations/master/fresnel_data.JSON")
            ).then(function(data) { // i.e., function(JSON1, JSON2) {// success}, function() {// error}
                data = data[0];
                init(data);

            });
            // , showJSONLoadError);

            function init(data) {
                phys.data = data;
                // endLoadingScreen();
                var traces = []
                //define the initial 3 traces
                traces.push({name: "Incident Wave", x: deepCopy(phys.getPlotData())[0].x,y:deepCopy(phys.getPlotData())[0].z,
                mode: "lines",line: {width: 3}})
                traces.push({name: "Transmitted Wave",x: deepCopy(phys.getPlotData())[4].x,y:deepCopy(phys.getPlotData())[4].z,
                mode: "lines",line: {width: 3,dash: "longdash"}})
                traces.push({name: "Reflected Wave",x: deepCopy(phys.getPlotData())[8].x,y:deepCopy(phys.getPlotData())[8].z,
                mode: "lines",line: {width: 3,dash: "longdash"}})
                //plot initial graph
                Plotly.newPlot('graph', traces, plt.layout,{displayModeBar: false, responsive: true});
                // let trace3 = {
                //     x: [0,1,2,3],
                //     y: [0,1,4,9]
                // };
                // Plotly.newPlot('graph', [trace3])

                refractiveIndexInput.on("input", handleRefractiveIndexSlider);
                angleInput.on("input", handleAngleSlider);
            }

            function handleRefractiveIndexSlider() {
                phys.setRefractiveIndexIndex(
                    input2index(v.refractiveIndexInput, phys.data[phys.polarisation])
                );
                updatePlot();
                dom.refractiveIndexDisplay.html(
                    roundInput(v.refractiveIndexInput, phys.data[phys.polarisation])
                );
            }

            function handleAngleSlider() {
                phys.setAngleIndex(
                    input2index2(v.angleInput, phys.data[phys.polarisation][phys.refractiveIndexIndex])
                );
                updatePlot();
                dom.angleDisplay.html(
                    roundInput(v.angleInput, phys.data[phys.polarisation][phys.refractiveIndexIndex]).concat('&deg;')
                );
            }

            function handleSliders() {
                phys.setRefractiveIndexIndex(
                    input2index(v.refractiveIndexInput, phys.data[phys.polarisation])
                );
                phys.setAngleIndex(
                    input2index2(v.angleInput, phys.data[phys.polarisation][phys.refractiveIndexIndex])
                );
                updatePlot();
            }

            // function endLoadingScreen() {
            //     dom.loadSpinner.fadeOut(0);
            // }

            function input2index(domInput, array) {
                /** Compute the corresponding JSON array index for a given input value, rounding to the nearest integer */
                var inputValue = domInput,
                    maxInput = 2,
                    minInput = 0.5,
                    arrayLen = array.length;
                return Math.round(((inputValue - minInput) / (maxInput - minInput)) * (arrayLen - 1));
            }

            function input2index2(domInput, array) {
                /** Compute the corresponding JSON array index for a given input value, rounding to the nearest integer */
                var inputValue = domInput,
                    maxInput = 85,
                    minInput = 0,
                    arrayLen = array.length;
                return Math.round(((inputValue - minInput) / (maxInput - minInput)) * (arrayLen - 1));
            }

            function roundInput(domInput, array) {
                /** Round a given input value to the actual value in the array. Returns a string */
                var maxInput = parseFloat(domInput.attr("max")),
                    minInput = parseFloat(domInput.attr("min")),
                    arrayLen = array.length;
                return (minInput + ((maxInput - minInput) / (arrayLen - 1)) * input2index(domInput, array)).toFixed(2);
            }

            function updatePlot() {
                console.log('update plot');
                var update = {},
                plotData = phys.getPlotData();
                update[0] = {
                    x: plotData[0].x,
                    y: plotData[0].z,
                    opacity: 1,
                }
                update[1] = {
                    x: plotData[4].x,
                    y: plotData[4].z,
                    opacity: 1,
                }
                update[2]={
                    x: [plotData[0].x[0],-1*plotData[0].x[1]],
                    y: plotData[0].z,
                    opacity: 1,
                }
                Plotly.animate("graph", {
                    data: getObjValues(update),
                    traces: getObjKeysAsInts(update),
                    layout: {}
                }, {
                    transition: {duration: 0},
                    frame: {duration: 0, redraw: false}
                });
            }

            // function showJSONLoadError() {
            //     dom.loadSpinner.children(".spinner-span").html("Error: Failed to load JSON resources");
            //     dom.loadSpinner.children("div").fadeOut(0);
            // }

            function getObjKeysAsInts(obj) {
                return Object.keys(obj).map(Number);
            }
            function getObjValues(obj) {
                return Object.keys(obj).map(function(key) {
                    return obj[key];
                });
            }
            function deepCopy(obj) {
                return JSON.parse(JSON.stringify(obj));
            }
        
        function redraw() {
            requestAnimationFrame(redraw);

            if(v.redrawPlot){
                v.redrawPlot = false;
                handleSliders();
                
            }
        }

        redraw();
    }
}
</script>
<style>
.iv-welcome-message{
    display:flex;
    flex-direction: column;
    align-items: center;
    margin-top: 50px;
}

input{
    margin-bottom: 3vh;
}
</style>